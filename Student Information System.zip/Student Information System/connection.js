var mysql = require("mysql2");

var con = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"stu_collegedetails",
    port:3307
});

con.connect((err) => {
    if (err) throw err;
    console.log("Connection created..!!");
});

module.exports = con;