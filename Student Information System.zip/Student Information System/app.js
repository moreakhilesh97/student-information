var con = require('./connection');
var express = require('express');
var app = express();
var bodyParser = require("body-parser");
const { __esModule } = require('formidable');

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({extended:true}))
app.set("view engine", "ejs");
app.set("views", "./view")
app.use(express.static(__dirname + "/public"))


app.get("/", (req, res) => {
    res.render("index");

});
app.get("/home",(req,res) => {
    res.render("index")
});

app.get("/registerstudent", (req, res) => {
    res.render('student');

});
app.get("/registercourse",(req,res) =>{
    res.render('course');
});
app.get("/courseinfo",(req,res) => {
    res.redirect('coursedetails');
});
app.get("/success",(req,res) =>{
    res.render("student");
});

app.get("/stuinfo",(req,res) => {
    res.redirect("/studetails");
});

app.get("/back", (req, res) => {
    res.redirect("/studetails");

});
app.get("/backhome",(req,res) =>{
    res.render("index");
});
app.get("/successmessage",(req,res) =>{
    res.render("successmessage");
});
app.get("/searchbar",(req,res) => {
   res.redirect("/search");
});
app.post('/registerstudent',function(req,res){
    var id = req.body.id;
    var fullname = req.body.fullname;
    var age = req.body.age;
    var email = req.body.email;
    var category = req.body.category;
    var state = req.body.state;
    var address = req.body.address;
    var phoneno = req.body.phoneno;
    var dob = req.body.dob;
    var gpa = req.body.gpa;

    con.connect(function(error){
        if(error) throw error;
        
        var sql = "INSERT INTO stu_info(id,fullname,age,email,category,state,address,phoneno,dob,gpa) VALUES (?,?,?,?,?,?,?,?,?,?)";
    con.query(sql,[id,fullname,age,email,category,state,address,phoneno,dob,gpa],function(error,result){
        if(error) throw error;
        res.redirect('/successmessage');
     //res.send('Student Registered Successfully'+result.insertId);

    });

});


});

app.post('/registercourse',function(req,res){
    var id = req.body.id;
    var fullname = req.body.fullname;
    var phoneno = req.body.phoneno;
    var coursename = req.body.coursename;
 

    con.connect(function(error){
        if(error) throw error;
        
        var sql = "INSERT INTO course(id,fullname,phoneno,coursename) VALUES (?,?,?,?)";
    con.query(sql,[id,fullname,phoneno,coursename],function(error,result){
        if(error) throw error;
   res.redirect('/coursedetails');
     //res.send('Student Registered Successfully'+result.insertId);

    });

});
});
app.get('/studetails',function(req,res){
    con.connect(function(error){
        if(error) console.log(error);
        var sql = "SELECT * FROM  stu_info";
        
        con.query(sql,function(error,result){
            if(error) console.log(error);
            console.log(result);
                        res.render(__dirname+"/studetails",{details:result});
        });
    });
});
app.get('/coursedetails',function(req,res){
    con.connect(function(error){
        if(error) console.log(error);
        var sql = "SELECT * FROM  course";
        
        con.query(sql,function(error,result){
            if(error) console.log(error);
            console.log(result);
                        res.render(__dirname+"/coursedetails",{details:result});
        });
    });
});




app.get('/deletestudent',function(req,res){
    con.connect(function(error){
        if(error) console.log(error);
        var sql = "delete from  stu_info where id=?";

        var id = req.query.id;
        
        con.query(sql,[id],function(error,result){
            if(error) console.log(error);
            console.log(result);
                     res.redirect('/studetails');
        });
    });
});


app.get('/deletestudent',function(req,res){
    con.connect(function(error){
        if(error) console.log(error);
        var sql = "delete from  course where id=?";

        var id = req.query.id;
        
        con.query(sql,[id],function(error,result){
            if(error) console.log(error);
            console.log(result);
                     res.redirect('/coursedetails');
        });
    });
});

app.get('/updatestudent',function(req,res){
    con.connect(function(error){
        if(error) console.log(error);
        var sql = "select * from  stu_info where id=?";

        var id = req.query.id;
        
        con.query(sql,[id],function(error,result){
            if(error) console.log(error);
            console.log(result);
                     res.render(__dirname+"/updatestudent",{details:result});
        });
    });
});


app.post('/updatestudent',function(req,res){

    var id = req.body.id;
    var fullname = req.body.fullname;
    var age = req.body.age;
    var email = req.body.email;
    var category = req.body.category;
    var state = req.body.state;
    var address = req.body.address;
    var phoneno = req.body.phoneno;
    var dob = req.body.dob;
    var gpa = req.body.gpa;
    
    con.connect(function(error){
        if(error) console.log(error);
        var sql = "UPDATE   stu_info set fullname=?,age=?,email=?,category=?,state=?,address=?,phoneno=?,dob=?,gpa=? where id=?";
        
        con.query(sql,[fullname,age,email,category,state,address,phoneno,dob,gpa,id],function(error,result){
            if(error) console.log(error);
                     res.redirect('/studetails');
        });
    });
});


app.get('/searchbar',function(req,res){
    con.connect(function(error){
        if(error)console.log(error);

        var sql = "SELECT * FROM stu_info";

        con.query(sql,function(error,result){

            if(error) console.log(error);
        
        res.render(__dirname+"/searchbar",{details:result});

});

});


});

app.get('/search',function(req,res){

    var id = req.query.id;
    con.connect(function(error){
        if(error) console.log(error);
        
        
        var sql = "SELECT * FROM stu_info where id like '%"+id+"%'";

        con.query(sql,function(error,result){
            if(error) console.log(error);

            res.render(__dirname+"/searchbar",{details:result});




        });
    });

});










app.listen('4000');